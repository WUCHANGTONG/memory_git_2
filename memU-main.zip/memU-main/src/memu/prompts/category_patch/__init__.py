from __future__ import annotations

from memu.prompts.category_patch.category import PROMPT

CATEGORY_PATCH_PROMPT = PROMPT.strip()

__all__ = ["CATEGORY_PATCH_PROMPT"]
