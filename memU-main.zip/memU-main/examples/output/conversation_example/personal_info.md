# personal_info
## Basic Information
- The user is named Alex and works as a software engineer at TechCorp.
