# relationships
## partner
- The user's partner enjoys photography and museums.
